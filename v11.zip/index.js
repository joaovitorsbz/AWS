const express = require('express');
const app = express();

const PORT = process.env.PORT || 80;

// Variável para contar os segundos desde o início do servidor
let counter = 0;

// Atualiza o contador de segundos a cada segundo
setInterval(() => {
    counter++;
}, 1000);

// Rota principal que inclui o contador de segundos
app.get('/', (req, res) => {
    res.send(`Hello, World! Elapsed time: ${counter} seconds.`);
});

// Nova rota /datetime que retorna a hora do servidor
app.get('/datetime', (req, res) => {
    const now = new Date();
    res.json({ datetime: now.toISOString() });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
